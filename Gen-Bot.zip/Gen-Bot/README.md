# A-Gen-Simplified-Working-Code
This is the A-Gen bot but the code is simplified
All you have to do is put in your token
